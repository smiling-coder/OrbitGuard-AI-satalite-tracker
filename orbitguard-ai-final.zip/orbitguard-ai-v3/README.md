# ORBITGUARD AI v3 (final)
Final additions: TLE import, compare two objects, 3D object label, backend check, tests, docs. See docs/.
v3 adds: AI Trajectory Predictor, Debris Detection Lab, Alert Intelligence, Atmospheric Drag Simulator, Reports and Analytics, Settings and About.

## v2
New in v2: Manoeuvre Simulator, Collision Event Simulator, Orbital Density Analysis.
Frontend (no build step): `cd frontend && python -m http.server 5500`, then open http://localhost:5500 (internet needed for Three.js, Chart.js and the Earth texture).
Backend (optional): `cd backend && pip install -r requirements.txt && uvicorn main:app --reload` then open http://127.0.0.1:8000/docs
All objects are SIMULATED unless imported from CSV. Screening results are not collision probabilities.
GitHub Pages: publish the `frontend/` folder. The current pages run fully in the browser; the backend is not needed.
